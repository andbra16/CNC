Added all the tokens in test.cpp and ran it with the lexer. The output was put into testOutput.cpp.

Compile: javac Lexer.java

Execute: java Lexer test.cpp
